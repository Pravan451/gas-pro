import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  integer,
  decimal,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("operator"), // operator, engineer, admin
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Gas sensor status enum
export const sensorStatusEnum = pgEnum("sensor_status", ["active", "inactive", "maintenance", "error"]);

// Valve status enum
export const valveStatusEnum = pgEnum("valve_status", ["open", "closed", "closing", "opening", "error"]);

// Alert severity enum
export const alertSeverityEnum = pgEnum("alert_severity", ["info", "warning", "critical", "emergency"]);

// Gas sensors table
export const sensors = pgTable("sensors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  zone: varchar("zone").notNull(),
  location: varchar("location").notNull(),
  sensorType: varchar("sensor_type").notNull(), // MQ-2, MQ-5, etc.
  status: sensorStatusEnum("status").default("active"),
  calibratedAt: timestamp("calibrated_at"),
  lastReading: decimal("last_reading", { precision: 10, scale: 2 }),
  readingUnit: varchar("reading_unit").default("PPM"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Gas valves table
export const valves = pgTable("valves", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  zone: varchar("zone").notNull(),
  location: varchar("location").notNull(),
  valveType: varchar("valve_type").notNull(), // main, emergency, backup
  status: valveStatusEnum("status").default("open"),
  isManualOverride: boolean("is_manual_override").default(false),
  lastOperatedAt: timestamp("last_operated_at"),
  operatedBy: varchar("operated_by"), // user id
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Sensor readings table for historical data
export const sensorReadings = pgTable("sensor_readings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sensorId: varchar("sensor_id").notNull().references(() => sensors.id),
  reading: decimal("reading", { precision: 10, scale: 2 }).notNull(),
  temperature: decimal("temperature", { precision: 5, scale: 2 }),
  humidity: decimal("humidity", { precision: 5, scale: 2 }),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

// System alerts table
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  severity: alertSeverityEnum("severity").notNull(),
  sensorId: varchar("sensor_id").references(() => sensors.id),
  valveId: varchar("valve_id").references(() => valves.id),
  isAcknowledged: boolean("is_acknowledged").default(false),
  acknowledgedBy: varchar("acknowledged_by"), // user id
  acknowledgedAt: timestamp("acknowledged_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// System logs table
export const systemLogs = pgTable("system_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  action: varchar("action").notNull(),
  description: text("description").notNull(),
  userId: varchar("user_id").references(() => users.id),
  entityType: varchar("entity_type"), // sensor, valve, system
  entityId: varchar("entity_id"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

// System settings table
export const systemSettings = pgTable("system_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  category: varchar("category").notNull(), // thresholds, notifications, system
  updatedBy: varchar("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// AI assistant conversations table
export const aiConversations = pgTable("ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  query: text("query").notNull(),
  response: text("response").notNull(),
  context: jsonb("context"), // sensor data, system state at time of query
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema exports
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Authenticated user type that includes claims from JWT/OIDC
export interface AuthenticatedUser extends User {
  claims: {
    sub: string;
    email?: string;
    first_name?: string;
    last_name?: string;
    profile_image_url?: string;
    exp?: number;
    [key: string]: any;
  };
  access_token?: string;
  refresh_token?: string;
  expires_at?: number;
}

export type InsertSensor = typeof sensors.$inferInsert;
export type Sensor = typeof sensors.$inferSelect;

export type InsertValve = typeof valves.$inferInsert;
export type Valve = typeof valves.$inferSelect;

export type InsertSensorReading = typeof sensorReadings.$inferInsert;
export type SensorReading = typeof sensorReadings.$inferSelect;

export type InsertAlert = typeof alerts.$inferInsert;
export type Alert = typeof alerts.$inferSelect;

export type InsertSystemLog = typeof systemLogs.$inferInsert;
export type SystemLog = typeof systemLogs.$inferSelect;

export type InsertSystemSetting = typeof systemSettings.$inferInsert;
export type SystemSetting = typeof systemSettings.$inferSelect;

export type InsertAiConversation = typeof aiConversations.$inferInsert;
export type AiConversation = typeof aiConversations.$inferSelect;

// Insert schemas for validation
export const insertSensorSchema = createInsertSchema(sensors).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertValveSchema = createInsertSchema(valves).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSensorReadingSchema = createInsertSchema(sensorReadings).omit({
  id: true,
  recordedAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
  createdAt: true,
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({
  id: true,
  createdAt: true,
});
