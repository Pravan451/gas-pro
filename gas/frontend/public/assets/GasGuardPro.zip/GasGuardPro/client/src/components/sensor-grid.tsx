import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Activity, AlertTriangle, CheckCircle, Clock, Thermometer, Droplets } from "lucide-react";

interface SensorGridProps {
  sensors: any[];
  readings: any[];
}

export default function SensorGrid({ sensors, readings }: SensorGridProps) {
  if (!sensors?.length) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Sensor Network
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No sensors configured</p>
            <p className="text-sm">Add sensors to monitor gas levels</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-success';
      case 'maintenance': return 'bg-warning';
      case 'error': return 'bg-destructive';
      default: return 'bg-muted';
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'maintenance': return 'outline';
      case 'error': return 'destructive';
      default: return 'secondary';
    }
  };

  const getReadingLevel = (value: number) => {
    if (value > 100) return { level: 'critical', color: 'text-destructive', progress: 100 };
    if (value > 50) return { level: 'warning', color: 'text-warning', progress: (value / 150) * 100 };
    return { level: 'safe', color: 'text-success', progress: (value / 150) * 100 };
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Sensor Network Status
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          {sensors.filter(s => s.status === 'active').length} of {sensors.length} sensors active
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sensors.map((sensor: any) => {
            const latestReading = readings.find((r: any) => r.sensorId === sensor.id);
            const gasValue = latestReading ? parseFloat(latestReading.reading) : 0;
            const temperature = latestReading?.temperature ? parseFloat(latestReading.temperature) : null;
            const humidity = latestReading?.humidity ? parseFloat(latestReading.humidity) : null;
            const readingLevel = getReadingLevel(gasValue);

            return (
              <Card key={sensor.id} className="bg-secondary border-border">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* Sensor Header */}
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-sm">{sensor.name}</h4>
                        <p className="text-xs text-muted-foreground">
                          Zone {sensor.zone} • {sensor.sensorType}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(sensor.status)} ${
                          sensor.status === 'active' ? 'animate-pulse' : ''
                        }`}></div>
                        <Badge variant={getStatusVariant(sensor.status)} className="text-xs">
                          {sensor.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>

                    {/* Gas Reading */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Gas Level</span>
                        <span className={`text-lg font-mono font-bold ${readingLevel.color}`}>
                          {gasValue.toFixed(1)} PPM
                        </span>
                      </div>
                      <Progress 
                        value={readingLevel.progress} 
                        className="h-2"
                        data-testid={`progress-gas-${sensor.id}`}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>0</span>
                        <span className="text-warning">50</span>
                        <span className="text-destructive">150 PPM</span>
                      </div>
                    </div>

                    {/* Environmental Data */}
                    {(temperature !== null || humidity !== null) && (
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border">
                        {temperature !== null && (
                          <div className="flex items-center gap-1">
                            <Thermometer className="h-3 w-3 text-primary" />
                            <span className="text-xs text-muted-foreground">
                              {temperature.toFixed(1)}°C
                            </span>
                          </div>
                        )}
                        {humidity !== null && (
                          <div className="flex items-center gap-1">
                            <Droplets className="h-3 w-3 text-primary" />
                            <span className="text-xs text-muted-foreground">
                              {humidity.toFixed(1)}%
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Sensor Info */}
                    <div className="pt-2 border-t border-border text-xs text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Location:</span>
                        <span>{sensor.location}</span>
                      </div>
                      {sensor.calibratedAt && (
                        <div className="flex justify-between mt-1">
                          <span>Last Cal:</span>
                          <span>{new Date(sensor.calibratedAt).toLocaleDateString()}</span>
                        </div>
                      )}
                      {latestReading?.recordedAt && (
                        <div className="flex justify-between mt-1">
                          <span>Updated:</span>
                          <span>{new Date(latestReading.recordedAt).toLocaleTimeString()}</span>
                        </div>
                      )}
                    </div>

                    {/* Status Icons */}
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex items-center gap-1">
                        {sensor.status === 'active' && <CheckCircle className="h-3 w-3 text-success" />}
                        {sensor.status === 'maintenance' && <Clock className="h-3 w-3 text-warning" />}
                        {sensor.status === 'error' && <AlertTriangle className="h-3 w-3 text-destructive" />}
                        <span className="text-xs text-muted-foreground">
                          {sensor.status === 'active' && 'Operational'}
                          {sensor.status === 'maintenance' && 'Maintenance'}
                          {sensor.status === 'error' && 'Error'}
                          {sensor.status === 'inactive' && 'Offline'}
                        </span>
                      </div>
                      
                      {readingLevel.level !== 'safe' && (
                        <AlertTriangle className={`h-4 w-4 ${
                          readingLevel.level === 'critical' ? 'text-destructive' : 'text-warning'
                        } animate-pulse`} />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
