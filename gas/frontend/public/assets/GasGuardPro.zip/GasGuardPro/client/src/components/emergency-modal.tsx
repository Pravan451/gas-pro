import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Power, Shield } from "lucide-react";

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function EmergencyModal({ isOpen, onClose }: EmergencyModalProps) {
  const { toast } = useToast();
  const [confirmationStep, setConfirmationStep] = useState(0);
  const [countdown, setCountdown] = useState(5);

  const emergencyShutdownMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/emergency/shutdown");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/valves"] });
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "Emergency Shutdown Completed",
        description: `${data.valvesClosed} valves have been closed. Safety protocols activated.`,
      });
      onClose();
      setConfirmationStep(0);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Emergency Shutdown Failed",
        description: "Failed to execute emergency shutdown. Contact system administrator immediately.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    onClose();
    setConfirmationStep(0);
    setCountdown(5);
  };

  const handleInitiateShutdown = () => {
    setConfirmationStep(1);
    
    // Start countdown
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleConfirmShutdown = () => {
    setConfirmationStep(2);
    emergencyShutdownMutation.mutate();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" data-testid="modal-emergency-shutdown">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Emergency Shutdown Confirmation
          </DialogTitle>
          <DialogDescription>
            This action will immediately stop all gas flow and trigger emergency protocols.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Warning Alert */}
          <Alert className="border-destructive/50 bg-destructive/10">
            <Shield className="h-4 w-4 text-destructive" />
            <AlertDescription className="text-destructive">
              <strong>⚠️ Critical Safety Action</strong><br />
              This will trigger emergency protocols and notify safety personnel. 
              Ensure all personnel are evacuated from affected zones.
            </AlertDescription>
          </Alert>

          {/* Confirmation Steps */}
          {confirmationStep === 0 && (
            <div className="space-y-4">
              <div className="bg-secondary rounded-lg p-4">
                <h4 className="font-medium mb-2">Emergency Shutdown Will:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Close all gas valves immediately</li>
                  <li>• Activate emergency ventilation</li>
                  <li>• Send alerts to safety personnel</li>
                  <li>• Log emergency action in audit trail</li>
                  <li>• Require manual system restart</li>
                </ul>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleClose}
                  className="flex-1"
                  data-testid="button-cancel-emergency"
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleInitiateShutdown}
                  className="flex-1"
                  data-testid="button-initiate-shutdown"
                >
                  <Power className="h-4 w-4 mr-2" />
                  Initiate Shutdown
                </Button>
              </div>
            </div>
          )}

          {confirmationStep === 1 && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-6xl font-bold text-destructive mb-2">{countdown}</div>
                <p className="text-sm text-muted-foreground">
                  Final confirmation required in {countdown} seconds
                </p>
                <Progress value={((5 - countdown) / 5) * 100} className="mt-2" />
              </div>

              <Alert className="border-warning/50 bg-warning/10">
                <AlertTriangle className="h-4 w-4 text-warning" />
                <AlertDescription className="text-warning">
                  <strong>Last chance to abort:</strong> Emergency shutdown will begin automatically 
                  when countdown reaches zero, or click confirm to proceed immediately.
                </AlertDescription>
              </Alert>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleClose}
                  className="flex-1"
                  data-testid="button-abort-shutdown"
                >
                  Abort
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleConfirmShutdown}
                  disabled={countdown > 0}
                  className="flex-1"
                  data-testid="button-confirm-shutdown"
                >
                  <Power className="h-4 w-4 mr-2" />
                  {countdown > 0 ? `Confirm (${countdown})` : 'Execute Shutdown'}
                </Button>
              </div>
            </div>
          )}

          {confirmationStep === 2 && (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 border-4 border-destructive border-t-transparent rounded-full animate-spin mx-auto"></div>
              <div>
                <h4 className="font-medium text-destructive mb-2">Emergency Shutdown In Progress</h4>
                <p className="text-sm text-muted-foreground">
                  {emergencyShutdownMutation.isPending ? 
                    'Closing valves and activating emergency protocols...' :
                    'Emergency shutdown completed successfully.'
                  }
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
