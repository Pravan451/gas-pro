import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, ChevronRight } from "lucide-react";

interface HeaderProps {
  title?: string;
  subtitle?: string;
  breadcrumbs?: Array<{ label: string; href?: string }>;
}

export default function Header({ title = "Dashboard", subtitle = "Real-time Monitoring", breadcrumbs }: HeaderProps) {
  const { user } = useAuth();

  const displayName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}`
    : user?.email?.split('@')[0] || 'System User';

  const initials = user?.firstName && user?.lastName
    ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
    : displayName.substring(0, 2);

  return (
    <header className="bg-card border-b border-border p-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        {breadcrumbs ? (
          <nav className="text-sm text-muted-foreground flex items-center">
            {breadcrumbs.map((crumb, index) => (
              <span key={index} className="flex items-center">
                {index > 0 && <ChevronRight className="h-4 w-4 mx-2" />}
                <span className={index === breadcrumbs.length - 1 ? 'text-foreground' : ''}>
                  {crumb.label}
                </span>
              </span>
            ))}
          </nav>
        ) : (
          <nav className="text-sm text-muted-foreground">
            <span>{title}</span>
            {subtitle && (
              <>
                <ChevronRight className="h-4 w-4 inline mx-2" />
                <span className="text-foreground">{subtitle}</span>
              </>
            )}
          </nav>
        )}
      </div>
      
      <div className="flex items-center gap-4">
        {/* Notification Bell */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="relative"
          data-testid="button-notifications"
        >
          <Bell className="h-4 w-4" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full"></span>
        </Button>
        
        {/* User Profile */}
        <div className="flex items-center gap-3 pl-4 border-l border-border">
          <div className="text-right">
            <p className="text-sm font-medium" data-testid="text-user-name">{displayName}</p>
            <Badge variant="outline" className="text-xs">
              Safety Engineer
            </Badge>
          </div>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-primary-foreground text-sm font-medium">
              {initials.toUpperCase()}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
