import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import RealTimeChart from "@/components/real-time-chart";
import SensorGrid from "@/components/sensor-grid";
import EmergencyModal from "@/components/emergency-modal";
import { Activity, AlertTriangle, Clock, Power, TrendingDown, Users, Shield, Settings } from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const { lastMessage, isConnected } = useWebSocket();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: sensors, isLoading: sensorsLoading } = useQuery({
    queryKey: ["/api/sensors"],
    retry: false,
  });

  const { data: valves, isLoading: valvesLoading } = useQuery({
    queryKey: ["/api/valves"],
    retry: false,
  });

  const { data: alerts, isLoading: alertsLoading } = useQuery({
    queryKey: ["/api/alerts"],
    retry: false,
  });

  const { data: latestReadings } = useQuery({
    queryKey: ["/api/sensor-readings/latest"],
    refetchInterval: 10000, // Refetch every 10 seconds
    retry: false,
  });

  if (isLoading || sensorsLoading || valvesLoading || alertsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const activeSensors = sensors?.filter((s: any) => s.status === 'active')?.length || 0;
  const totalSensors = sensors?.length || 0;
  const activeAlerts = alerts?.filter((a: any) => !a.isAcknowledged)?.length || 0;
  const criticalAlerts = alerts?.filter((a: any) => a.severity === 'critical' && !a.isAcknowledged) || [];
  const warningAlerts = alerts?.filter((a: any) => a.severity === 'warning' && !a.isAcknowledged) || [];

  // Calculate average gas levels
  const averageGasLevel = latestReadings?.length 
    ? (latestReadings.reduce((acc: number, reading: any) => acc + parseFloat(reading.reading), 0) / latestReadings.length).toFixed(1)
    : "0.0";

  return (
    <div className="p-6 space-y-6">
      {/* Connection Status */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Real-time Monitoring</h1>
          <p className="text-muted-foreground">Industrial gas detection dashboard</p>
        </div>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-success animate-pulse' : 'bg-destructive'}`}></div>
          <span className="text-sm text-muted-foreground">
            {isConnected ? 'Live' : 'Disconnected'}
          </span>
        </div>
      </div>

      {/* Critical Alerts */}
      {criticalAlerts.length > 0 && (
        <Alert className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertDescription className="text-destructive">
            <strong>Critical Alert:</strong> {criticalAlerts[0].message}
            <Button 
              variant="link" 
              className="text-destructive p-0 ml-2 h-auto"
              onClick={() => window.location.href = '/emergency'}
              data-testid="link-emergency"
            >
              View Emergency Panel
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Warning Alerts */}
      {warningAlerts.length > 0 && (
        <Alert className="border-warning/50 bg-warning/10">
          <AlertTriangle className="h-4 w-4 text-warning" />
          <AlertDescription className="text-warning">
            <strong>Warning:</strong> {warningAlerts[0].message}
            <Button 
              variant="link" 
              className="text-warning p-0 ml-2 h-auto"
              data-testid="button-acknowledge-warning"
            >
              Acknowledge
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">Active Sensors</h3>
              <div className={`w-3 h-3 rounded-full ${activeSensors === totalSensors ? 'bg-success animate-pulse' : 'bg-warning'}`}></div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground" data-testid="text-active-sensors">{activeSensors}</span>
              <span className="text-muted-foreground">/ {totalSensors}</span>
            </div>
            <p className={`text-xs mt-2 ${activeSensors === totalSensors ? 'text-success' : 'text-warning'}`}>
              {activeSensors === totalSensors ? 'All sensors operational' : `${totalSensors - activeSensors} sensors offline`}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">Gas Levels</h3>
              <Activity className="h-4 w-4 text-primary" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground font-mono" data-testid="text-gas-level">{averageGasLevel}</span>
              <span className="text-muted-foreground">PPM</span>
            </div>
            <p className="text-xs text-success mt-2">
              <TrendingDown className="inline h-3 w-3 mr-1" />
              Within safe limits
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">Active Alerts</h3>
              <AlertTriangle className={`h-4 w-4 ${activeAlerts > 0 ? 'text-destructive' : 'text-success'}`} />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground" data-testid="text-active-alerts">{activeAlerts}</span>
              <span className="text-muted-foreground">today</span>
            </div>
            <p className={`text-xs mt-2 ${activeAlerts === 0 ? 'text-success' : 'text-warning'}`}>
              {activeAlerts === 0 ? 'System operational' : 'Requires attention'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">System Uptime</h3>
              <Clock className="h-4 w-4 text-success" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground" data-testid="text-uptime">99.8</span>
              <span className="text-muted-foreground">%</span>
            </div>
            <p className="text-xs text-success mt-2">Excellent performance</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-Time Chart */}
        <div className="lg:col-span-2">
          <RealTimeChart 
            readings={latestReadings || []} 
            sensors={sensors || []}
            lastMessage={lastMessage}
          />
        </div>

        {/* Valve Controls */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Valve Controls
            </CardTitle>
            <p className="text-sm text-muted-foreground">Manual override available</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {valves?.slice(0, 3).map((valve: any) => (
                <div key={valve.id} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                  <div>
                    <p className="font-medium text-sm">{valve.name}</p>
                    <p className="text-xs text-muted-foreground">{valve.zone}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      valve.status === 'open' ? 'bg-success animate-pulse' :
                      valve.status === 'closed' ? 'bg-muted' :
                      'bg-warning animate-pulse'
                    }`}></div>
                    <Badge variant={
                      valve.status === 'open' ? 'default' :
                      valve.status === 'closed' ? 'secondary' :
                      'destructive'
                    } className="text-xs">
                      {valve.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>

            <Button 
              className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              onClick={() => setShowEmergencyModal(true)}
              data-testid="button-emergency-shutdown"
            >
              <Power className="h-4 w-4 mr-2" />
              Emergency Shutdown
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.location.href = '/valve-control'}
              data-testid="button-manual-override"
            >
              Manual Override
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Sensor Grid */}
      <SensorGrid 
        sensors={sensors || []} 
        readings={latestReadings || []}
      />

      {/* Emergency Modal */}
      <EmergencyModal 
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
      />
    </div>
  );
}
