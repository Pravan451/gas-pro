import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Bot, 
  Send, 
  TrendingUp, 
  AlertTriangle, 
  Lightbulb,
  FileText,
  BarChart3,
  Brain,
  Clock,
  User
} from "lucide-react";

interface Conversation {
  id: string;
  query: string;
  response: string;
  createdAt: string;
}

export default function AIAssistant() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [query, setQuery] = useState("");
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ["/api/ai/conversations"],
    retry: false,
  });

  const { data: sensors } = useQuery({
    queryKey: ["/api/sensors"],
    retry: false,
  });

  const { data: latestReadings } = useQuery({
    queryKey: ["/api/sensor-readings/latest"],
    retry: false,
  });

  const { data: alerts } = useQuery({
    queryKey: ["/api/alerts"],
    retry: false,
  });

  const chatMutation = useMutation({
    mutationFn: async ({ query, context }: { query: string; context?: any }) => {
      const response = await apiRequest("POST", "/api/ai/chat", { query, context });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
      setQuery("");
      toast({
        title: "AI Response Generated",
        description: "Your query has been processed successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to process AI request",
        variant: "destructive",
      });
    },
  });

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      const analysisData = {
        sensorData: latestReadings?.map((r: any) => ({
          zone: sensors?.find((s: any) => s.id === r.sensorId)?.zone || 'Unknown',
          reading: parseFloat(r.reading),
          timestamp: r.recordedAt,
        })) || [],
        systemStatus: {
          activeSensors: sensors?.filter((s: any) => s.status === 'active')?.length || 0,
          totalSensors: sensors?.length || 0,
          uptime: 99.8,
        },
        recentAlerts: alerts?.slice(0, 5).map((a: any) => ({
          severity: a.severity,
          message: a.message,
          timestamp: a.createdAt,
        })) || [],
      };

      const response = await apiRequest("POST", "/api/ai/analyze", analysisData);
      return response.json();
    },
    onSuccess: (data) => {
      // Create a conversation entry with the analysis results
      const analysisQuery = "Please analyze current system data and provide safety recommendations";
      const analysisResponse = `## AI Analysis Results\n\n**Risk Assessment**: ${data.riskAssessment.level.toUpperCase()}\n${data.riskAssessment.explanation}\n\n**Recommendations**:\n${data.recommendations.map((r: string) => `• ${r}`).join('\n')}\n\n**Predictive Insights**:\n${data.predictiveInsights.map((i: string) => `• ${i}`).join('\n')}\n\n**Immediate Actions**:\n${data.immediateActions.map((a: string) => `• ${a}`).join('\n')}`;
      
      chatMutation.mutate({ 
        query: analysisQuery, 
        context: { analysisType: 'system_analysis', data } 
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to analyze system data",
        variant: "destructive",
      });
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/report", {
        sensorData: latestReadings || [],
        timeRange: "24 hours"
      });
      return response.json();
    },
    onSuccess: (data) => {
      const reportQuery = "Generate a comprehensive safety report for the last 24 hours";
      chatMutation.mutate({ 
        query: reportQuery, 
        context: { reportType: 'safety_report', report: data.report } 
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate safety report",
        variant: "destructive",
      });
    },
  });

  if (isLoading || conversationsLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading AI assistant...</p>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    const context = {
      activeSensors: sensors?.filter((s: any) => s.status === 'active')?.length || 0,
      totalSensors: sensors?.length || 0,
      activeAlerts: alerts?.filter((a: any) => !a.isAcknowledged)?.length || 0,
      latestReadings: latestReadings?.slice(0, 5) || [],
    };

    chatMutation.mutate({ query: query.trim(), context });
  };

  const quickActions = [
    {
      title: "Analyze Current Data",
      description: "Get AI insights on current sensor readings and system status",
      icon: BarChart3,
      action: () => analyzeMutation.mutate(),
      loading: analyzeMutation.isPending,
    },
    {
      title: "Generate Safety Report",
      description: "Create a comprehensive safety report for management",
      icon: FileText,
      action: () => generateReportMutation.mutate(),
      loading: generateReportMutation.isPending,
    },
    {
      title: "Predictive Analysis",
      description: "Forecast potential issues based on historical patterns",
      icon: TrendingUp,
      action: () => chatMutation.mutate({ 
        query: "Analyze historical gas level patterns and predict potential issues in the next 24-48 hours",
        context: { requestType: 'predictive_analysis' }
      }),
      loading: false,
    },
    {
      title: "Emergency Protocols",
      description: "Review emergency response procedures and protocols",
      icon: AlertTriangle,
      action: () => chatMutation.mutate({ 
        query: "What are the current emergency response protocols I should follow if gas levels exceed critical thresholds?",
        context: { requestType: 'emergency_protocols' }
      }),
      loading: false,
    },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Bot className="h-6 w-6" />
            AI Safety Assistant
          </h1>
          <p className="text-muted-foreground">Intelligent safety analysis and recommendations powered by OpenAI</p>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <Brain className="h-3 w-3" />
          GPT-5 Powered
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Interface */}
        <div className="lg:col-span-2 space-y-4">
          {/* Quick Actions */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5" />
                Quick AI Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-auto p-4 flex flex-col items-start gap-2"
                    onClick={action.action}
                    disabled={action.loading || chatMutation.isPending}
                    data-testid={`button-quick-action-${index}`}
                  >
                    <div className="flex items-center gap-2 w-full">
                      <action.icon className="h-4 w-4" />
                      <span className="font-medium text-sm">{action.title}</span>
                    </div>
                    <p className="text-xs text-muted-foreground text-left">
                      {action.description}
                    </p>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Messages */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>Conversation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="max-h-96 overflow-y-auto space-y-4">
                {conversations?.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Bot className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Start a conversation with the AI assistant</p>
                    <p className="text-sm">Ask about gas patterns, safety protocols, or system diagnostics</p>
                  </div>
                ) : (
                  conversations?.map((conversation: Conversation) => (
                    <div key={conversation.id} className="space-y-3">
                      {/* User Query */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                          <User className="h-4 w-4 text-primary-foreground" />
                        </div>
                        <div className="flex-1 bg-primary/10 rounded-lg p-3">
                          <p className="text-sm">{conversation.query}</p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {new Date(conversation.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>

                      {/* AI Response */}
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 bg-success rounded-lg flex items-center justify-center flex-shrink-0">
                          <Bot className="h-4 w-4 text-success-foreground" />
                        </div>
                        <div className="flex-1 bg-secondary rounded-lg p-3">
                          <div className="prose prose-sm max-w-none">
                            <pre className="whitespace-pre-wrap text-sm font-sans">
                              {conversation.response}
                            </pre>
                          </div>
                        </div>
                      </div>
                      <Separator />
                    </div>
                  ))
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSubmit} className="flex gap-2">
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Ask about gas patterns, safety protocols, diagnostics..."
                  disabled={chatMutation.isPending}
                  className="flex-1"
                  data-testid="input-ai-query"
                />
                <Button 
                  type="submit" 
                  disabled={!query.trim() || chatMutation.isPending}
                  data-testid="button-send-query"
                >
                  {chatMutation.isPending ? (
                    <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* System Context Panel */}
        <div className="space-y-4">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                System Context
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium text-sm mb-2">Current Status</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active Sensors:</span>
                    <span>{sensors?.filter((s: any) => s.status === 'active')?.length || 0}/{sensors?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active Alerts:</span>
                    <span className="text-warning">{alerts?.filter((a: any) => !a.isAcknowledged)?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">System Uptime:</span>
                    <span className="text-success">99.8%</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium text-sm mb-2">Recent Readings</h4>
                <div className="space-y-2">
                  {latestReadings?.slice(0, 3).map((reading: any) => {
                    const sensor = sensors?.find((s: any) => s.id === reading.sensorId);
                    const level = parseFloat(reading.reading);
                    return (
                      <div key={reading.id} className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{sensor?.zone}:</span>
                        <span className={`font-mono ${
                          level > 100 ? 'text-destructive' :
                          level > 50 ? 'text-warning' :
                          'text-success'
                        }`}>
                          {level.toFixed(1)} PPM
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                AI Capabilities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <span className="text-muted-foreground">Real-time gas pattern analysis</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <span className="text-muted-foreground">Predictive maintenance scheduling</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <span className="text-muted-foreground">Emergency protocol guidance</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <span className="text-muted-foreground">Safety compliance reporting</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <span className="text-muted-foreground">Risk assessment and mitigation</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
