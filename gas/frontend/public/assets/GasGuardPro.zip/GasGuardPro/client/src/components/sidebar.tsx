import { Link, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  BarChart3, 
  Settings, 
  AlertTriangle, 
  Bot, 
  FileText, 
  Cog,
  Power
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: BarChart3, label: "Dashboard", active: location === "/" },
    { path: "/valve-control", icon: Settings, label: "Valve Control", active: location === "/valve-control" },
    { path: "/emergency", icon: AlertTriangle, label: "Emergency", active: location === "/emergency" },
    { path: "/ai-assistant", icon: Bot, label: "AI Assistant", active: location === "/ai-assistant" },
    { path: "/logs", icon: FileText, label: "Logs", active: location === "/logs" },
    { path: "/settings", icon: Cog, label: "Settings", active: location === "/settings" },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex-shrink-0 flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 p-6 border-b border-border">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
          <Shield className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-lg font-semibold">GasGuard Pro</h1>
          <p className="text-xs text-muted-foreground">V7.2.1</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2 flex-1">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a 
              className={`nav-item flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                item.active 
                  ? 'bg-accent text-accent-foreground' 
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
              data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
            >
              <item.icon className={`h-4 w-4 ${item.active ? 'text-primary' : ''}`} />
              <span className={item.active ? 'font-medium' : ''}>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>

      {/* System Status */}
      <div className="p-4">
        <div className="bg-secondary p-4 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">System Status</span>
            <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
          </div>
          <p className="text-xs text-muted-foreground mb-3">All sensors operational</p>
          <div className="space-y-1 text-xs text-muted-foreground">
            <div className="flex justify-between">
              <span>Uptime:</span>
              <span className="text-success">99.8%</span>
            </div>
            <div className="flex justify-between">
              <span>Active:</span>
              <span>24h</span>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Logout */}
      <div className="p-4 border-t border-border">
        <button
          onClick={() => window.location.href = "/api/logout"}
          className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-accent rounded-md transition-colors"
          data-testid="button-logout"
        >
          <Power className="h-4 w-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
