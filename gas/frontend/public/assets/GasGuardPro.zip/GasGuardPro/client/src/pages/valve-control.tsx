import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Power, Lock, Unlock, AlertTriangle, CheckCircle } from "lucide-react";

export default function ValveControl() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedValve, setSelectedValve] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: valves, isLoading: valvesLoading } = useQuery({
    queryKey: ["/api/valves"],
    retry: false,
  });

  const { data: sensors } = useQuery({
    queryKey: ["/api/sensors"],
    retry: false,
  });

  const updateValveMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      const response = await apiRequest("PATCH", `/api/valves/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/valves"] });
      toast({
        title: "Success",
        description: "Valve updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update valve",
        variant: "destructive",
      });
    },
  });

  const emergencyShutdownMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/emergency/shutdown");
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/valves"] });
      toast({
        title: "Emergency Shutdown Completed",
        description: `${data.valvesClosed} valves have been closed`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to execute emergency shutdown",
        variant: "destructive",
      });
    },
  });

  if (isLoading || valvesLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading valve controls...</p>
        </div>
      </div>
    );
  }

  const handleValveToggle = (valve: any) => {
    const newStatus = valve.status === 'open' ? 'closed' : 'open';
    updateValveMutation.mutate({
      id: valve.id,
      updates: { status: newStatus }
    });
  };

  const handleManualOverride = (valve: any) => {
    updateValveMutation.mutate({
      id: valve.id,
      updates: { isManualOverride: !valve.isManualOverride }
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-success';
      case 'closed': return 'bg-muted';
      case 'closing': return 'bg-warning animate-pulse';
      case 'opening': return 'bg-primary animate-pulse';
      case 'error': return 'bg-destructive';
      default: return 'bg-muted';
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'open': return 'default';
      case 'closed': return 'secondary';
      case 'closing': 
      case 'opening': return 'outline';
      case 'error': return 'destructive';
      default: return 'secondary';
    }
  };

  const groupedValves = valves?.reduce((acc: any, valve: any) => {
    if (!acc[valve.zone]) acc[valve.zone] = [];
    acc[valve.zone].push(valve);
    return acc;
  }, {}) || {};

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Valve Control System</h1>
          <p className="text-muted-foreground">Manual valve operation and emergency controls</p>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant="destructive"
            onClick={() => emergencyShutdownMutation.mutate()}
            disabled={emergencyShutdownMutation.isPending}
            data-testid="button-emergency-shutdown-all"
          >
            <Power className="h-4 w-4 mr-2" />
            {emergencyShutdownMutation.isPending ? 'Shutting Down...' : 'Emergency Shutdown All'}
          </Button>
        </div>
      </div>

      {/* Safety Warning */}
      <Alert className="border-warning/50 bg-warning/10">
        <AlertTriangle className="h-4 w-4 text-warning" />
        <AlertDescription className="text-warning">
          <strong>Safety Notice:</strong> Manual valve operations should only be performed by authorized personnel. 
          Emergency protocols will be activated for critical operations.
        </AlertDescription>
      </Alert>

      {/* Valve Controls by Zone */}
      <div className="space-y-6">
        {Object.entries(groupedValves).map(([zone, zoneValves]: [string, any]) => (
          <Card key={zone} className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Zone {zone} Valves
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                {zoneValves.length} valve{zoneValves.length !== 1 ? 's' : ''} in this zone
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {zoneValves.map((valve: any) => (
                  <Card 
                    key={valve.id} 
                    className={`bg-secondary border-border transition-all cursor-pointer hover:shadow-md ${
                      selectedValve === valve.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedValve(selectedValve === valve.id ? null : valve.id)}
                    data-testid={`card-valve-${valve.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-sm">{valve.name}</h4>
                          <p className="text-xs text-muted-foreground">{valve.valveType} valve</p>
                        </div>
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(valve.status)}`}></div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">Status:</span>
                          <Badge variant={getStatusVariant(valve.status)} className="text-xs">
                            {valve.status.toUpperCase()}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">Manual Override:</span>
                          <div className="flex items-center gap-2">
                            {valve.isManualOverride ? 
                              <Unlock className="h-3 w-3 text-warning" /> : 
                              <Lock className="h-3 w-3 text-muted-foreground" />
                            }
                            <Switch
                              checked={valve.isManualOverride}
                              onCheckedChange={() => handleManualOverride(valve)}
                              disabled={updateValveMutation.isPending}
                              data-testid={`switch-override-${valve.id}`}
                            />
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button
                            size="sm"
                            variant={valve.status === 'open' ? 'destructive' : 'default'}
                            className="flex-1 text-xs"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleValveToggle(valve);
                            }}
                            disabled={updateValveMutation.isPending || valve.status === 'error'}
                            data-testid={`button-toggle-${valve.id}`}
                          >
                            {valve.status === 'open' ? 'Close' : 'Open'}
                          </Button>
                        </div>

                        {valve.lastOperatedAt && (
                          <p className="text-xs text-muted-foreground pt-2 border-t border-border">
                            Last operated: {new Date(valve.lastOperatedAt).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* System Status Summary */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            System Status Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">
                {valves?.filter((v: any) => v.status === 'open').length || 0}
              </div>
              <p className="text-sm text-muted-foreground">Open Valves</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">
                {valves?.filter((v: any) => v.status === 'closed').length || 0}
              </div>
              <p className="text-sm text-muted-foreground">Closed Valves</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-warning">
                {valves?.filter((v: any) => v.isManualOverride).length || 0}
              </div>
              <p className="text-sm text-muted-foreground">Manual Override</p>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-destructive">
                {valves?.filter((v: any) => v.status === 'error').length || 0}
              </div>
              <p className="text-sm text-muted-foreground">Error State</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
