import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  AlertTriangle, 
  Power, 
  Shield, 
  Clock, 
  CheckCircle,
  XCircle,
  Phone,
  Mail,
  Radio
} from "lucide-react";
import EmergencyModal from "@/components/emergency-modal";

export default function Emergency() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: alerts, isLoading: alertsLoading } = useQuery({
    queryKey: ["/api/alerts"],
    retry: false,
  });

  const { data: sensors } = useQuery({
    queryKey: ["/api/sensors"],
    retry: false,
  });

  const { data: valves } = useQuery({
    queryKey: ["/api/valves"],
    retry: false,
  });

  const { data: latestReadings } = useQuery({
    queryKey: ["/api/sensor-readings/latest"],
    retry: false,
  });

  const acknowledgeAlertMutation = useMutation({
    mutationFn: async (alertId: string) => {
      const response = await apiRequest("PATCH", `/api/alerts/${alertId}/acknowledge`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "Alert Acknowledged",
        description: "Alert has been acknowledged successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to acknowledge alert",
        variant: "destructive",
      });
    },
  });

  if (isLoading || alertsLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading emergency panel...</p>
        </div>
      </div>
    );
  }

  const criticalAlerts = alerts?.filter((a: any) => a.severity === 'critical' && !a.isAcknowledged) || [];
  const warningAlerts = alerts?.filter((a: any) => a.severity === 'warning' && !a.isAcknowledged) || [];
  const infoAlerts = alerts?.filter((a: any) => a.severity === 'info' && !a.isAcknowledged) || [];
  const acknowledgedAlerts = alerts?.filter((a: any) => a.isAcknowledged) || [];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': 
      case 'emergency': return 'text-destructive';
      case 'warning': return 'text-warning';
      case 'info': return 'text-primary';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical': 
      case 'emergency': return 'destructive';
      case 'warning': return 'outline';
      case 'info': return 'secondary';
      default: return 'secondary';
    }
  };

  // Calculate system risk level
  const highRiskReadings = latestReadings?.filter((r: any) => parseFloat(r.reading) > 50) || [];
  const criticalRiskReadings = latestReadings?.filter((r: any) => parseFloat(r.reading) > 100) || [];
  
  const systemRiskLevel = criticalRiskReadings.length > 0 ? 'critical' : 
                         highRiskReadings.length > 0 ? 'high' : 
                         warningAlerts.length > 0 ? 'medium' : 'low';

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Emergency Management
          </h1>
          <p className="text-muted-foreground">Critical alerts and emergency response controls</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm font-medium">System Risk Level</p>
            <Badge 
              variant={systemRiskLevel === 'critical' ? 'destructive' : 
                      systemRiskLevel === 'high' ? 'destructive' :
                      systemRiskLevel === 'medium' ? 'outline' : 'secondary'}
              className="mt-1"
            >
              {systemRiskLevel.toUpperCase()}
            </Badge>
          </div>
          <Button
            variant="destructive"
            size="lg"
            onClick={() => setShowEmergencyModal(true)}
            data-testid="button-emergency-shutdown"
          >
            <Power className="h-4 w-4 mr-2" />
            Emergency Shutdown
          </Button>
        </div>
      </div>

      {/* Emergency Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-destructive/10 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold text-destructive" data-testid="text-critical-alerts">
                  {criticalAlerts.length}
                </p>
                <p className="text-sm text-muted-foreground">Critical Alerts</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-warning/10 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-4 w-4 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold text-warning" data-testid="text-warning-alerts">
                  {warningAlerts.length}
                </p>
                <p className="text-sm text-muted-foreground">Warning Alerts</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground" data-testid="text-acknowledged-alerts">
                  {acknowledgedAlerts.length}
                </p>
                <p className="text-sm text-muted-foreground">Acknowledged</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
                <Shield className="h-4 w-4 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {valves?.filter((v: any) => v.status === 'closed').length || 0}
                </p>
                <p className="text-sm text-muted-foreground">Valves Secured</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Critical Alerts */}
      {criticalAlerts.length > 0 && (
        <Card className="bg-card border-destructive/50">
          <CardHeader>
            <CardTitle className="text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Critical Alerts - Immediate Action Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {criticalAlerts.map((alert: any) => (
              <div key={alert.id} className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-semibold text-destructive mb-1">{alert.title}</h4>
                    <p className="text-sm text-destructive/80 mb-2">{alert.message}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(alert.createdAt).toLocaleString()}
                      </span>
                      {alert.sensorId && (
                        <span>Sensor: {sensors?.find((s: any) => s.id === alert.sensorId)?.name}</span>
                      )}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => acknowledgeAlertMutation.mutate(alert.id)}
                    disabled={acknowledgeAlertMutation.isPending}
                    data-testid={`button-acknowledge-${alert.id}`}
                  >
                    Acknowledge
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Warning Alerts */}
      {warningAlerts.length > 0 && (
        <Card className="bg-card border-warning/50">
          <CardHeader>
            <CardTitle className="text-warning flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Warning Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {warningAlerts.map((alert: any) => (
              <div key={alert.id} className="bg-warning/10 border border-warning/20 rounded-lg p-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-warning mb-1">{alert.title}</h4>
                    <p className="text-sm text-warning/80 mb-2">{alert.message}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(alert.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => acknowledgeAlertMutation.mutate(alert.id)}
                    disabled={acknowledgeAlertMutation.isPending}
                    data-testid={`button-acknowledge-warning-${alert.id}`}
                  >
                    Acknowledge
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Emergency Response Procedures */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Emergency Response Procedures
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="h-4 w-4 text-primary" />
                <h4 className="font-medium">Emergency Contacts</h4>
              </div>
              <div className="space-y-1 text-sm">
                <p>Fire Department: 911</p>
                <p>Safety Officer: (555) 123-4567</p>
                <p>Plant Manager: (555) 123-4568</p>
              </div>
            </div>

            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Radio className="h-4 w-4 text-primary" />
                <h4 className="font-medium">Communication</h4>
              </div>
              <div className="space-y-1 text-sm">
                <p>Radio Channel: 16</p>
                <p>PA System: Zone Alert</p>
                <p>SMS Alerts: Enabled</p>
              </div>
            </div>

            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4 text-primary" />
                <h4 className="font-medium">Response Actions</h4>
              </div>
              <div className="space-y-1 text-sm">
                <p>✓ Evacuate affected zones</p>
                <p>✓ Close isolation valves</p>
                <p>✓ Activate ventilation</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Alert History */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Recent Alert History</CardTitle>
          <p className="text-sm text-muted-foreground">Last 24 hours of alert activity</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts?.slice(0, 10).map((alert: any) => (
              <div key={alert.id} className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${
                    alert.severity === 'critical' ? 'bg-destructive' :
                    alert.severity === 'warning' ? 'bg-warning' :
                    'bg-primary'
                  }`}></div>
                  <div>
                    <p className="font-medium text-sm">{alert.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(alert.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={getSeverityBadge(alert.severity)} className="text-xs">
                    {alert.severity.toUpperCase()}
                  </Badge>
                  {alert.isAcknowledged ? (
                    <CheckCircle className="h-4 w-4 text-success" />
                  ) : (
                    <XCircle className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <EmergencyModal 
        isOpen={showEmergencyModal}
        onClose={() => setShowEmergencyModal(false)}
      />
    </div>
  );
}
