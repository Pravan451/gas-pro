import { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface RealTimeChartProps {
  readings: any[];
  sensors: any[];
  lastMessage?: any;
}

export default function RealTimeChart({ readings, sensors, lastMessage }: RealTimeChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dataPointsRef = useRef<{ [key: string]: number[] }>({});
  const timeLabelsRef = useRef<string[]>([]);

  useEffect(() => {
    // Initialize data points for each sensor
    sensors?.forEach((sensor: any) => {
      if (!dataPointsRef.current[sensor.id]) {
        dataPointsRef.current[sensor.id] = [];
      }
    });
  }, [sensors]);

  useEffect(() => {
    if (lastMessage?.type === 'sensor_update' && lastMessage.data) {
      // Update data points with new readings
      lastMessage.data.forEach((reading: any) => {
        if (dataPointsRef.current[reading.sensorId]) {
          dataPointsRef.current[reading.sensorId].push(reading.reading);
          // Keep only last 50 data points
          if (dataPointsRef.current[reading.sensorId].length > 50) {
            dataPointsRef.current[reading.sensorId].shift();
          }
        }
      });

      // Update time labels
      timeLabelsRef.current.push(new Date().toLocaleTimeString());
      if (timeLabelsRef.current.length > 50) {
        timeLabelsRef.current.shift();
      }

      drawChart();
    }
  }, [lastMessage]);

  useEffect(() => {
    // Initial chart draw
    drawChart();
  }, [readings, sensors]);

  const drawChart = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = canvas;
    ctx.clearRect(0, 0, width, height);

    // Chart dimensions
    const padding = 40;
    const chartWidth = width - 2 * padding;
    const chartHeight = height - 2 * padding;

    // Draw grid
    ctx.strokeStyle = 'hsl(240 6% 20%)';
    ctx.lineWidth = 1;

    // Horizontal grid lines
    for (let i = 0; i <= 5; i++) {
      const y = padding + (chartHeight / 5) * i;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(padding + chartWidth, y);
      ctx.stroke();
    }

    // Vertical grid lines
    for (let i = 0; i <= 10; i++) {
      const x = padding + (chartWidth / 10) * i;
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, padding + chartHeight);
      ctx.stroke();
    }

    // Draw axes labels
    ctx.fillStyle = 'hsl(240 5% 64%)';
    ctx.font = '12px Inter';
    ctx.textAlign = 'center';

    // Y-axis labels (PPM values)
    ctx.textAlign = 'right';
    for (let i = 0; i <= 5; i++) {
      const y = padding + (chartHeight / 5) * i;
      const value = 150 - (i * 30); // Max 150 PPM, step 30
      ctx.fillText(`${value}`, padding - 10, y + 4);
    }

    // X-axis label
    ctx.textAlign = 'center';
    ctx.fillText('Time', width / 2, height - 10);

    // Draw sensor data lines
    const colors = ['hsl(217 91% 60%)', 'hsl(142 76% 36%)', 'hsl(38 92% 50%)', 'hsl(0 84% 60%)'];
    let colorIndex = 0;

    Object.entries(dataPointsRef.current).forEach(([sensorId, dataPoints]) => {
      if (dataPoints.length < 2) return;

      ctx.strokeStyle = colors[colorIndex % colors.length];
      ctx.lineWidth = 2;
      ctx.beginPath();

      dataPoints.forEach((value, index) => {
        const x = padding + (chartWidth / (dataPoints.length - 1)) * index;
        const y = padding + chartHeight - (value / 150) * chartHeight; // Scale to 150 PPM max

        if (index === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      ctx.stroke();

      // Draw data points
      ctx.fillStyle = colors[colorIndex % colors.length];
      dataPoints.forEach((value, index) => {
        const x = padding + (chartWidth / (dataPoints.length - 1)) * index;
        const y = padding + chartHeight - (value / 150) * chartHeight;
        
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, 2 * Math.PI);
        ctx.fill();
      });

      colorIndex++;
    });
  };

  // Get latest readings for each zone
  const zoneReadings = sensors?.map((sensor: any) => {
    const latestReading = readings.find((r: any) => r.sensorId === sensor.id);
    const currentValue = latestReading ? parseFloat(latestReading.reading) : 0;
    const previousValue = dataPointsRef.current[sensor.id]?.slice(-2, -1)[0] || currentValue;
    
    return {
      zone: sensor.zone,
      value: currentValue,
      trend: currentValue > previousValue ? 'up' : currentValue < previousValue ? 'down' : 'stable',
      status: currentValue > 100 ? 'critical' : currentValue > 50 ? 'warning' : 'safe'
    };
  }) || [];

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Real-Time Gas Monitoring</CardTitle>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm text-muted-foreground">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Chart Canvas */}
          <div className="bg-gradient-to-br from-card to-secondary rounded-lg p-4 h-80">
            <canvas
              ref={canvasRef}
              width={600}
              height={300}
              className="w-full h-full"
              style={{ maxWidth: '100%', height: 'auto' }}
            />
          </div>

          {/* Zone Readings */}
          <div className="grid grid-cols-3 gap-4 text-center">
            {zoneReadings.map((zone, index) => (
              <div key={zone.zone} className="space-y-2">
                <div className="flex items-center justify-center gap-1">
                  <p className={`text-2xl font-mono font-bold ${
                    zone.status === 'critical' ? 'text-destructive' :
                    zone.status === 'warning' ? 'text-warning' : 
                    'text-success'
                  }`}>
                    {zone.value.toFixed(1)}
                  </p>
                  {zone.trend === 'up' && <TrendingUp className="h-4 w-4 text-destructive" />}
                  {zone.trend === 'down' && <TrendingDown className="h-4 w-4 text-success" />}
                  {zone.trend === 'stable' && <Minus className="h-4 w-4 text-muted-foreground" />}
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Zone {zone.zone} (PPM)</p>
                  <Badge 
                    variant={
                      zone.status === 'critical' ? 'destructive' :
                      zone.status === 'warning' ? 'outline' : 
                      'secondary'
                    }
                    className="text-xs"
                  >
                    {zone.status.toUpperCase()}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
