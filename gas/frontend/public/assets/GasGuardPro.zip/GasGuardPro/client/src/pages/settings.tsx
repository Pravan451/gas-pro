import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Settings, 
  Bell, 
  Shield, 
  Gauge, 
  Users, 
  Database,
  Save,
  AlertTriangle,
  CheckCircle,
  Smartphone,
  Mail,
  Radio
} from "lucide-react";

export default function SettingsPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
    retry: false,
  });

  const { data: sensors } = useQuery({
    queryKey: ["/api/sensors"],
    retry: false,
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: any[]) => {
      const response = await apiRequest("PUT", "/api/settings", updatedSettings);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setHasUnsavedChanges(false);
      toast({
        title: "Settings Updated",
        description: "System settings have been saved successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    },
  });

  if (isLoading || settingsLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading settings...</p>
        </div>
      </div>
    );
  }

  // Group settings by category
  const settingsByCategory = (settings || []).reduce((acc: any, setting: any) => {
    if (!acc[setting.category]) acc[setting.category] = [];
    acc[setting.category].push(setting);
    return acc;
  }, {});

  // Default settings if none exist
  const defaultSettings = {
    thresholds: [
      { key: 'warning_threshold', value: '50', description: 'Warning threshold for gas levels (PPM)', category: 'thresholds' },
      { key: 'critical_threshold', value: '100', description: 'Critical threshold for gas levels (PPM)', category: 'thresholds' },
      { key: 'emergency_threshold', value: '150', description: 'Emergency threshold for gas levels (PPM)', category: 'thresholds' },
    ],
    notifications: [
      { key: 'sms_alerts', value: 'true', description: 'Enable SMS alert notifications', category: 'notifications' },
      { key: 'email_alerts', value: 'true', description: 'Enable email notifications', category: 'notifications' },
      { key: 'push_notifications', value: 'true', description: 'Enable push notifications', category: 'notifications' },
      { key: 'alert_frequency', value: '5', description: 'Alert frequency in minutes', category: 'notifications' },
    ],
    system: [
      { key: 'data_retention', value: '90', description: 'Data retention period in days', category: 'system' },
      { key: 'sensor_polling', value: '5', description: 'Sensor polling interval in seconds', category: 'system' },
      { key: 'auto_calibration', value: 'true', description: 'Enable automatic sensor calibration', category: 'system' },
      { key: 'maintenance_mode', value: 'false', description: 'System maintenance mode', category: 'system' },
    ]
  };

  const currentSettings = Object.keys(settingsByCategory).length > 0 ? settingsByCategory : defaultSettings;

  const handleSettingChange = (category: string, key: string, value: string) => {
    setHasUnsavedChanges(true);
    // Update local state logic would go here
  };

  const handleSave = () => {
    // Prepare settings for API call
    const allSettings = Object.values(currentSettings).flat().map((setting: any) => ({
      key: setting.key,
      value: setting.value,
      description: setting.description,
      category: setting.category
    }));

    updateSettingsMutation.mutate(allSettings);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Settings className="h-6 w-6" />
            System Settings
          </h1>
          <p className="text-muted-foreground">Configure system thresholds, notifications, and preferences</p>
        </div>
        <div className="flex items-center gap-2">
          {hasUnsavedChanges && (
            <Badge variant="outline" className="text-warning border-warning">
              Unsaved Changes
            </Badge>
          )}
          <Button 
            onClick={handleSave}
            disabled={!hasUnsavedChanges || updateSettingsMutation.isPending}
            data-testid="button-save-settings"
          >
            <Save className="h-4 w-4 mr-2" />
            {updateSettingsMutation.isPending ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="thresholds" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="thresholds" className="flex items-center gap-2">
            <Gauge className="h-4 w-4" />
            Thresholds
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="system" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            System
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
        </TabsList>

        {/* Gas Level Thresholds */}
        <TabsContent value="thresholds" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gauge className="h-5 w-5" />
                Gas Detection Thresholds
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure alert thresholds for gas concentration levels (PPM)
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-warning rounded-full"></div>
                    <h4 className="font-medium">Warning Level</h4>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="warning-threshold">Threshold (PPM)</Label>
                    <Input
                      id="warning-threshold"
                      type="number"
                      defaultValue="50"
                      onChange={(e) => handleSettingChange('thresholds', 'warning_threshold', e.target.value)}
                      data-testid="input-warning-threshold"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Triggers warning alerts and increased monitoring
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-destructive rounded-full"></div>
                    <h4 className="font-medium">Critical Level</h4>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="critical-threshold">Threshold (PPM)</Label>
                    <Input
                      id="critical-threshold"
                      type="number"
                      defaultValue="100"
                      onChange={(e) => handleSettingChange('thresholds', 'critical_threshold', e.target.value)}
                      data-testid="input-critical-threshold"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Triggers critical alerts and safety protocols
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-destructive rounded-full animate-pulse"></div>
                    <h4 className="font-medium">Emergency Level</h4>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emergency-threshold">Threshold (PPM)</Label>
                    <Input
                      id="emergency-threshold"
                      type="number"
                      defaultValue="150"
                      onChange={(e) => handleSettingChange('thresholds', 'emergency_threshold', e.target.value)}
                      data-testid="input-emergency-threshold"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Triggers emergency shutdown and evacuation
                  </p>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Sensor Calibration Settings</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="calibration-interval">Auto-calibration Interval (hours)</Label>
                    <Input
                      id="calibration-interval"
                      type="number"
                      defaultValue="24"
                      data-testid="input-calibration-interval"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sensitivity">Sensor Sensitivity</Label>
                    <Input
                      id="sensitivity"
                      type="number"
                      step="0.1"
                      defaultValue="1.0"
                      data-testid="input-sensor-sensitivity"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Alert & Notification Settings
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure how and when you receive alerts
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-secondary border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Smartphone className="h-5 w-5 text-primary" />
                      <h4 className="font-medium">SMS Alerts</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Enable SMS notifications</span>
                        <Switch defaultChecked data-testid="switch-sms-alerts" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sms-number">Phone Number</Label>
                        <Input
                          id="sms-number"
                          placeholder="+1 (555) 123-4567"
                          data-testid="input-sms-number"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-secondary border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Mail className="h-5 w-5 text-primary" />
                      <h4 className="font-medium">Email Notifications</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Enable email alerts</span>
                        <Switch defaultChecked data-testid="switch-email-alerts" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email-address">Email Address</Label>
                        <Input
                          id="email-address"
                          type="email"
                          placeholder="alerts@company.com"
                          data-testid="input-email-address"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-secondary border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <Radio className="h-5 w-5 text-primary" />
                      <h4 className="font-medium">Emergency Broadcast</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">PA system alerts</span>
                        <Switch defaultChecked data-testid="switch-pa-alerts" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="radio-channel">Radio Channel</Label>
                        <Input
                          id="radio-channel"
                          type="number"
                          defaultValue="16"
                          data-testid="input-radio-channel"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Alert Frequency & Escalation</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="alert-interval">Alert Repeat Interval (minutes)</Label>
                    <Input
                      id="alert-interval"
                      type="number"
                      defaultValue="5"
                      data-testid="input-alert-interval"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="escalation-time">Escalation Time (minutes)</Label>
                    <Input
                      id="escalation-time"
                      type="number"
                      defaultValue="15"
                      data-testid="input-escalation-time"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Settings */}
        <TabsContent value="system" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                System Configuration
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure system behavior and data management
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Data Management</h4>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="retention-period">Data Retention (days)</Label>
                      <Input
                        id="retention-period"
                        type="number"
                        defaultValue="90"
                        data-testid="input-data-retention"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="backup-frequency">Backup Frequency (hours)</Label>
                      <Input
                        id="backup-frequency"
                        type="number"
                        defaultValue="24"
                        data-testid="input-backup-frequency"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Monitoring Settings</h4>
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="polling-interval">Sensor Polling Interval (seconds)</Label>
                      <Input
                        id="polling-interval"
                        type="number"
                        defaultValue="5"
                        data-testid="input-polling-interval"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="log-level">System Log Level</Label>
                      <select className="w-full p-2 border border-border rounded-md bg-background" data-testid="select-log-level">
                        <option value="info">Info</option>
                        <option value="warning">Warning</option>
                        <option value="error">Error</option>
                        <option value="debug">Debug</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">System Toggles</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Auto-calibration</span>
                      <p className="text-sm text-muted-foreground">Automatic sensor calibration</p>
                    </div>
                    <Switch defaultChecked data-testid="switch-auto-calibration" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Predictive Analytics</span>
                      <p className="text-sm text-muted-foreground">AI-powered predictions</p>
                    </div>
                    <Switch defaultChecked data-testid="switch-predictive-analytics" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Maintenance Mode</span>
                      <p className="text-sm text-muted-foreground">Disable certain alerts</p>
                    </div>
                    <Switch data-testid="switch-maintenance-mode" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Debug Logging</span>
                      <p className="text-sm text-muted-foreground">Enhanced system logging</p>
                    </div>
                    <Switch data-testid="switch-debug-logging" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Status */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle>System Status & Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium">System Version</h4>
                  <p className="text-sm text-muted-foreground">GasGuard Pro V7.2.1</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Database Status</h4>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-success" />
                    <span className="text-sm text-success">Connected</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Last Backup</h4>
                  <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security & Access Control
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure security settings and user access
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="font-medium">Current User</h4>
                <div className="bg-secondary rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-primary-foreground font-medium">
                        {user?.firstName?.charAt(0) || 'U'}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">
                        {user?.firstName && user?.lastName 
                          ? `${user.firstName} ${user.lastName}` 
                          : 'System User'}
                      </p>
                      <p className="text-sm text-muted-foreground">{user?.email || 'No email'}</p>
                      <Badge variant="outline" className="mt-1">Safety Engineer</Badge>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Security Features</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Two-Factor Authentication</span>
                      <p className="text-sm text-muted-foreground">Enhanced login security</p>
                    </div>
                    <Switch data-testid="switch-2fa" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Session Timeout</span>
                      <p className="text-sm text-muted-foreground">Auto-logout after inactivity</p>
                    </div>
                    <Switch defaultChecked data-testid="switch-session-timeout" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-medium">Audit Logging</span>
                      <p className="text-sm text-muted-foreground">Track all user actions</p>
                    </div>
                    <Switch defaultChecked data-testid="switch-audit-logging" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">Emergency Access</h4>
                <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-warning mt-0.5" />
                    <div>
                      <h5 className="font-medium text-warning">Emergency Override Code</h5>
                      <p className="text-sm text-warning/80 mt-1">
                        Master override code for emergency situations when normal authentication fails.
                      </p>
                      <Button variant="outline" size="sm" className="mt-2 border-warning text-warning hover:bg-warning hover:text-warning-foreground">
                        Generate New Code
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
