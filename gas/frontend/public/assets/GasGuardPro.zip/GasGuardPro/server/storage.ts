import {
  users,
  sensors,
  valves,
  sensorReadings,
  alerts,
  systemLogs,
  systemSettings,
  aiConversations,
  type User,
  type UpsertUser,
  type Sensor,
  type InsertSensor,
  type Valve,
  type InsertValve,
  type SensorReading,
  type InsertSensorReading,
  type Alert,
  type InsertAlert,
  type SystemLog,
  type InsertSystemLog,
  type SystemSetting,
  type InsertSystemSetting,
  type AiConversation,
  type InsertAiConversation,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Sensor operations
  getSensors(): Promise<Sensor[]>;
  getSensor(id: string): Promise<Sensor | undefined>;
  createSensor(sensor: InsertSensor): Promise<Sensor>;
  updateSensor(id: string, updates: Partial<InsertSensor>): Promise<Sensor>;
  
  // Valve operations
  getValves(): Promise<Valve[]>;
  getValve(id: string): Promise<Valve | undefined>;
  createValve(valve: InsertValve): Promise<Valve>;
  updateValve(id: string, updates: Partial<InsertValve>): Promise<Valve>;
  
  // Sensor readings
  createSensorReading(reading: InsertSensorReading): Promise<SensorReading>;
  getSensorReadings(sensorId?: string, limit?: number): Promise<SensorReading[]>;
  getLatestReadings(): Promise<SensorReading[]>;
  
  // Alerts
  getAlerts(limit?: number): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  acknowledgeAlert(id: string, userId: string): Promise<Alert>;
  
  // System logs
  getSystemLogs(limit?: number): Promise<SystemLog[]>;
  createSystemLog(log: InsertSystemLog): Promise<SystemLog>;
  
  // System settings
  getSystemSettings(): Promise<SystemSetting[]>;
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  upsertSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
  
  // AI conversations
  getAiConversations(userId: string, limit?: number): Promise<AiConversation[]>;
  createAiConversation(conversation: InsertAiConversation): Promise<AiConversation>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Sensor operations
  async getSensors(): Promise<Sensor[]> {
    return await db.select().from(sensors);
  }

  async getSensor(id: string): Promise<Sensor | undefined> {
    const [sensor] = await db.select().from(sensors).where(eq(sensors.id, id));
    return sensor;
  }

  async createSensor(sensor: InsertSensor): Promise<Sensor> {
    const [newSensor] = await db.insert(sensors).values(sensor).returning();
    return newSensor;
  }

  async updateSensor(id: string, updates: Partial<InsertSensor>): Promise<Sensor> {
    const [sensor] = await db
      .update(sensors)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(sensors.id, id))
      .returning();
    return sensor;
  }

  // Valve operations
  async getValves(): Promise<Valve[]> {
    return await db.select().from(valves);
  }

  async getValve(id: string): Promise<Valve | undefined> {
    const [valve] = await db.select().from(valves).where(eq(valves.id, id));
    return valve;
  }

  async createValve(valve: InsertValve): Promise<Valve> {
    const [newValve] = await db.insert(valves).values(valve).returning();
    return newValve;
  }

  async updateValve(id: string, updates: Partial<InsertValve>): Promise<Valve> {
    const [valve] = await db
      .update(valves)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(valves.id, id))
      .returning();
    return valve;
  }

  // Sensor readings
  async createSensorReading(reading: InsertSensorReading): Promise<SensorReading> {
    const [newReading] = await db.insert(sensorReadings).values(reading).returning();
    return newReading;
  }

  async getSensorReadings(sensorId?: string, limit = 100): Promise<SensorReading[]> {
    let query = db.select().from(sensorReadings);
    
    if (sensorId) {
      query = query.where(eq(sensorReadings.sensorId, sensorId));
    }
    
    return await query.orderBy(desc(sensorReadings.recordedAt)).limit(limit);
  }

  async getLatestReadings(): Promise<SensorReading[]> {
    // Get the latest reading for each sensor
    return await db.select().from(sensorReadings)
      .orderBy(desc(sensorReadings.recordedAt))
      .limit(50); // Adjust based on number of sensors
  }

  // Alerts
  async getAlerts(limit = 50): Promise<Alert[]> {
    return await db.select().from(alerts)
      .orderBy(desc(alerts.createdAt))
      .limit(limit);
  }

  async createAlert(alert: InsertAlert): Promise<Alert> {
    const [newAlert] = await db.insert(alerts).values(alert).returning();
    return newAlert;
  }

  async acknowledgeAlert(id: string, userId: string): Promise<Alert> {
    const [alert] = await db
      .update(alerts)
      .set({
        isAcknowledged: true,
        acknowledgedBy: userId,
        acknowledgedAt: new Date(),
      })
      .where(eq(alerts.id, id))
      .returning();
    return alert;
  }

  // System logs
  async getSystemLogs(limit = 100): Promise<SystemLog[]> {
    return await db.select().from(systemLogs)
      .orderBy(desc(systemLogs.createdAt))
      .limit(limit);
  }

  async createSystemLog(log: InsertSystemLog): Promise<SystemLog> {
    const [newLog] = await db.insert(systemLogs).values(log).returning();
    return newLog;
  }

  // System settings
  async getSystemSettings(): Promise<SystemSetting[]> {
    return await db.select().from(systemSettings);
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting;
  }

  async upsertSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const [newSetting] = await db
      .insert(systemSettings)
      .values(setting)
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: {
          ...setting,
          updatedAt: new Date(),
        },
      })
      .returning();
    return newSetting;
  }

  // AI conversations
  async getAiConversations(userId: string, limit = 50): Promise<AiConversation[]> {
    return await db.select().from(aiConversations)
      .where(eq(aiConversations.userId, userId))
      .orderBy(desc(aiConversations.createdAt))
      .limit(limit);
  }

  async createAiConversation(conversation: InsertAiConversation): Promise<AiConversation> {
    const [newConversation] = await db.insert(aiConversations).values(conversation).returning();
    return newConversation;
  }
}

export const storage = new DatabaseStorage();
