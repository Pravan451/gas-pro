import { AuthenticatedUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends AuthenticatedUser {}
  }
}