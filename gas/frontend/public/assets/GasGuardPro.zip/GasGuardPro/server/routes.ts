import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { analyzeGasData, chatWithAI, generateSafetyReport } from "./openai";
import { 
  insertSensorSchema, 
  insertValveSchema, 
  insertSensorReadingSchema,
  insertAlertSchema,
  insertSystemLogSchema,
  insertSystemSettingSchema,
  insertAiConversationSchema
} from "@shared/schema";


export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Sensor routes
  app.get("/api/sensors", isAuthenticated, async (req, res) => {
    try {
      const sensors = await storage.getSensors();
      res.json(sensors);
    } catch (error) {
      console.error("Error fetching sensors:", error);
      res.status(500).json({ message: "Failed to fetch sensors" });
    }
  });

  app.post("/api/sensors", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertSensorSchema.parse(req.body);
      const sensor = await storage.createSensor(validatedData);
      
      // Log the action
      await storage.createSystemLog({
        action: "sensor_created",
        description: `New sensor ${sensor.name} created in ${sensor.zone}`,
        userId: req.user?.claims?.sub,
        entityType: "sensor",
        entityId: sensor.id,
      });
      
      res.json(sensor);
    } catch (error) {
      console.error("Error creating sensor:", error);
      res.status(500).json({ message: "Failed to create sensor" });
    }
  });

  app.patch("/api/sensors/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const sensor = await storage.updateSensor(id, updates);
      
      await storage.createSystemLog({
        action: "sensor_updated",
        description: `Sensor ${sensor.name} updated`,
        userId: req.user?.claims?.sub,
        entityType: "sensor",
        entityId: sensor.id,
        metadata: updates,
      });
      
      res.json(sensor);
    } catch (error) {
      console.error("Error updating sensor:", error);
      res.status(500).json({ message: "Failed to update sensor" });
    }
  });

  // Valve routes
  app.get("/api/valves", isAuthenticated, async (req, res) => {
    try {
      const valves = await storage.getValves();
      res.json(valves);
    } catch (error) {
      console.error("Error fetching valves:", error);
      res.status(500).json({ message: "Failed to fetch valves" });
    }
  });

  app.post("/api/valves", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertValveSchema.parse(req.body);
      const valve = await storage.createValve(validatedData);
      
      await storage.createSystemLog({
        action: "valve_created",
        description: `New valve ${valve.name} created in ${valve.zone}`,
        userId: req.user?.claims?.sub,
        entityType: "valve",
        entityId: valve.id,
      });
      
      res.json(valve);
    } catch (error) {
      console.error("Error creating valve:", error);
      res.status(500).json({ message: "Failed to create valve" });
    }
  });

  app.patch("/api/valves/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = { ...req.body, operatedBy: req.user?.claims?.sub, lastOperatedAt: new Date() };
      const valve = await storage.updateValve(id, updates);
      
      await storage.createSystemLog({
        action: "valve_operated",
        description: `Valve ${valve.name} status changed to ${valve.status}`,
        userId: req.user?.claims?.sub,
        entityType: "valve",
        entityId: valve.id,
        metadata: updates,
      });
      
      res.json(valve);
    } catch (error) {
      console.error("Error updating valve:", error);
      res.status(500).json({ message: "Failed to update valve" });
    }
  });

  // Emergency shutdown
  app.post("/api/emergency/shutdown", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      
      // Close all valves
      const valves = await storage.getValves();
      const updates = [];
      
      for (const valve of valves) {
        const updated = await storage.updateValve(valve.id, {
          status: "closed",
          operatedBy: userId,
          lastOperatedAt: new Date(),
        });
        updates.push(updated);
      }
      
      // Create critical alert
      await storage.createAlert({
        title: "Emergency Shutdown Activated",
        message: "All valves have been closed due to emergency shutdown",
        severity: "emergency",
      });
      
      // Log the emergency action
      await storage.createSystemLog({
        action: "emergency_shutdown",
        description: "Emergency shutdown activated - all valves closed",
        userId,
        entityType: "system",
        metadata: { valvesClosed: updates.length },
      });
      
      res.json({ success: true, valvesClosed: updates.length });
    } catch (error) {
      console.error("Error during emergency shutdown:", error);
      res.status(500).json({ message: "Failed to execute emergency shutdown" });
    }
  });

  // Sensor readings routes
  app.get("/api/sensor-readings", isAuthenticated, async (req, res) => {
    try {
      const { sensorId, limit } = req.query;
      const readings = await storage.getSensorReadings(
        sensorId as string, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(readings);
    } catch (error) {
      console.error("Error fetching sensor readings:", error);
      res.status(500).json({ message: "Failed to fetch sensor readings" });
    }
  });

  app.get("/api/sensor-readings/latest", isAuthenticated, async (req, res) => {
    try {
      const readings = await storage.getLatestReadings();
      res.json(readings);
    } catch (error) {
      console.error("Error fetching latest readings:", error);
      res.status(500).json({ message: "Failed to fetch latest readings" });
    }
  });

  // Alerts routes
  app.get("/api/alerts", isAuthenticated, async (req, res) => {
    try {
      const { limit } = req.query;
      const alerts = await storage.getAlerts(limit ? parseInt(limit as string) : undefined);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.patch("/api/alerts/:id/acknowledge", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.user?.claims?.sub;
      const alert = await storage.acknowledgeAlert(id, userId);
      
      await storage.createSystemLog({
        action: "alert_acknowledged",
        description: `Alert acknowledged: ${alert.title}`,
        userId,
        entityType: "alert",
        entityId: alert.id,
      });
      
      res.json(alert);
    } catch (error) {
      console.error("Error acknowledging alert:", error);
      res.status(500).json({ message: "Failed to acknowledge alert" });
    }
  });

  // System logs routes
  app.get("/api/logs", isAuthenticated, async (req, res) => {
    try {
      const { limit } = req.query;
      const logs = await storage.getSystemLogs(limit ? parseInt(limit as string) : undefined);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching logs:", error);
      res.status(500).json({ message: "Failed to fetch logs" });
    }
  });

  // System settings routes
  app.get("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.getSystemSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.put("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const settings = req.body;
      const updatedSettings = [];
      
      for (const setting of settings) {
        const validatedData = insertSystemSettingSchema.parse({
          ...setting,
          updatedBy: userId,
        });
        const updated = await storage.upsertSystemSetting(validatedData);
        updatedSettings.push(updated);
      }
      
      await storage.createSystemLog({
        action: "settings_updated",
        description: `${updatedSettings.length} system settings updated`,
        userId,
        entityType: "system",
        metadata: { settingsCount: updatedSettings.length },
      });
      
      res.json(updatedSettings);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  // AI assistant routes
  app.get("/api/ai/conversations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const { limit } = req.query;
      const conversations = await storage.getAiConversations(
        userId, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching AI conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post("/api/ai/chat", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const { query, context } = req.body;
      
      const response = await chatWithAI(query, context);
      
      const conversation = await storage.createAiConversation({
        userId,
        query,
        response,
        context,
      });
      
      res.json(conversation);
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ message: "Failed to process AI request" });
    }
  });

  app.post("/api/ai/analyze", isAuthenticated, async (req, res) => {
    try {
      const analysisData = req.body;
      const analysis = await analyzeGasData(analysisData);
      res.json(analysis);
    } catch (error) {
      console.error("Error in AI analysis:", error);
      res.status(500).json({ message: "Failed to analyze data" });
    }
  });

  app.post("/api/ai/report", isAuthenticated, async (req, res) => {
    try {
      const { sensorData, timeRange } = req.body;
      const report = await generateSafetyReport(sensorData, timeRange);
      res.json({ report });
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message);
        console.log('Received:', data);
        
        // Handle different message types
        if (data.type === 'subscribe') {
          // Client wants to subscribe to real-time updates
          ws.send(JSON.stringify({ type: 'subscribed', message: 'Successfully subscribed to real-time updates' }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Simulate real-time sensor data
  setInterval(async () => {
    try {
      const sensors = await storage.getSensors();
      const sensorData = [];
      
      for (const sensor of sensors) {
        if (sensor.status === 'active') {
          // Generate realistic gas readings
          const baseReading = parseFloat(sensor.lastReading || "5");
          const variation = (Math.random() - 0.5) * 10;
          const newReading = Math.max(0, Math.min(150, baseReading + variation));
          
          // Create sensor reading
          await storage.createSensorReading({
            sensorId: sensor.id,
            reading: newReading.toString(),
            temperature: (20 + Math.random() * 10).toFixed(1),
            humidity: (40 + Math.random() * 20).toFixed(1),
          });
          
          // Update sensor last reading
          await storage.updateSensor(sensor.id, {
            lastReading: newReading.toString(),
          });
          
          sensorData.push({
            sensorId: sensor.id,
            zone: sensor.zone,
            reading: newReading,
            timestamp: new Date().toISOString(),
          });
          
          // Check thresholds and create alerts
          if (newReading > 100) {
            await storage.createAlert({
              title: "Critical Gas Level",
              message: `Critical gas levels detected in ${sensor.zone}: ${newReading.toFixed(1)} PPM`,
              severity: "critical",
              sensorId: sensor.id,
            });
          } else if (newReading > 50) {
            await storage.createAlert({
              title: "High Gas Level",
              message: `Elevated gas levels in ${sensor.zone}: ${newReading.toFixed(1)} PPM`,
              severity: "warning",
              sensorId: sensor.id,
            });
          }
        }
      }
      
      // Broadcast to all connected WebSocket clients
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            type: 'sensor_update',
            data: sensorData,
            timestamp: new Date().toISOString(),
          }));
        }
      });
    } catch (error) {
      console.error('Error in sensor simulation:', error);
    }
  }, 5000); // Update every 5 seconds

  return httpServer;
}
