import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface GasAnalysisRequest {
  sensorData: Array<{
    zone: string;
    reading: number;
    timestamp: string;
  }>;
  systemStatus: {
    activeSensors: number;
    totalSensors: number;
    uptime: number;
  };
  recentAlerts: Array<{
    severity: string;
    message: string;
    timestamp: string;
  }>;
}

export interface GasAnalysisResponse {
  recommendations: string[];
  riskAssessment: {
    level: "low" | "medium" | "high" | "critical";
    explanation: string;
  };
  predictiveInsights: string[];
  immediateActions: string[];
}

export async function analyzeGasData(data: GasAnalysisRequest): Promise<GasAnalysisResponse> {
  try {
    const prompt = `
You are an expert industrial gas safety analyst. Analyze the following gas detection system data and provide safety recommendations.

Current Sensor Data:
${data.sensorData.map(s => `Zone ${s.zone}: ${s.reading} PPM at ${s.timestamp}`).join('\n')}

System Status:
- Active Sensors: ${data.systemStatus.activeSensors}/${data.systemStatus.totalSensors}
- System Uptime: ${data.systemStatus.uptime}%

Recent Alerts:
${data.recentAlerts.map(a => `${a.severity}: ${a.message} (${a.timestamp})`).join('\n')}

Provide analysis in JSON format with:
1. recommendations: Array of specific safety recommendations
2. riskAssessment: Object with level ("low", "medium", "high", "critical") and explanation
3. predictiveInsights: Array of predictions based on current trends
4. immediateActions: Array of actions that should be taken immediately

Consider industrial safety thresholds:
- 0-10 PPM: Safe
- 10-50 PPM: Caution/Warning
- 50-100 PPM: Danger
- 100+ PPM: Critical/Emergency

Focus on actionable insights for industrial safety engineers.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert industrial gas safety analyst. Provide detailed, actionable safety analysis in valid JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      recommendations: result.recommendations || [],
      riskAssessment: result.riskAssessment || { level: "medium", explanation: "Unable to assess risk" },
      predictiveInsights: result.predictiveInsights || [],
      immediateActions: result.immediateActions || []
    };
  } catch (error) {
    console.error("Error analyzing gas data:", error);
    throw new Error("Failed to analyze gas data: " + (error as Error).message);
  }
}

export async function chatWithAI(query: string, context?: any): Promise<string> {
  try {
    const systemPrompt = `
You are an AI assistant for GasGuard Pro, an industrial gas detection and safety system. 
You help safety engineers and operators with:
- Gas detection patterns and analysis
- Safety protocols and emergency procedures
- System maintenance and troubleshooting
- Regulatory compliance guidance
- Predictive maintenance scheduling

Always provide practical, safety-focused advice. If asked about anything outside of gas safety and industrial monitoring, politely redirect to safety-related topics.
`;

    const contextPrompt = context ? `\n\nCurrent system context: ${JSON.stringify(context)}` : "";

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: systemPrompt + contextPrompt
        },
        {
          role: "user",
          content: query
        }
      ],
      max_completion_tokens: 1000,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't process your request. Please try again.";
  } catch (error) {
    console.error("Error in AI chat:", error);
    throw new Error("Failed to process AI request: " + (error as Error).message);
  }
}

export async function generateSafetyReport(sensorData: any[], timeRange: string): Promise<string> {
  try {
    const prompt = `
Generate a comprehensive safety report for the GasGuard Pro system based on the following sensor data over ${timeRange}:

${JSON.stringify(sensorData, null, 2)}

Include:
1. Executive summary of safety status
2. Key findings and trends
3. Risk areas identified
4. Maintenance recommendations
5. Compliance status
6. Recommended actions

Format as a professional safety report suitable for management review.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a professional safety report writer specializing in industrial gas detection systems."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_completion_tokens: 2000,
    });

    return response.choices[0].message.content || "Unable to generate safety report at this time.";
  } catch (error) {
    console.error("Error generating safety report:", error);
    throw new Error("Failed to generate safety report: " + (error as Error).message);
  }
}
